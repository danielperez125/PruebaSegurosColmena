-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: colmena_seguros
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `line_id` int NOT NULL,
  `name` varchar(200) NOT NULL,
  `details` varchar(400) DEFAULT NULL,
  `base_price` decimal(10,2) NOT NULL,
  `state` int NOT NULL,
  `user_id_add` int NOT NULL,
  `date_add` datetime NOT NULL,
  `user_id_mod` int DEFAULT NULL,
  `date_mod` datetime DEFAULT NULL,
  PRIMARY KEY (`product_id`),
  KEY `state_prod_idx` (`state`),
  KEY `line_id_prod_idx` (`line_id`),
  KEY `user_id_add_prod_idx` (`user_id_add`),
  KEY `user_id_mod_prod_idx` (`user_id_mod`),
  CONSTRAINT `line_id_prod` FOREIGN KEY (`line_id`) REFERENCES `line` (`line_id`),
  CONSTRAINT `state_prod` FOREIGN KEY (`state`) REFERENCES `states` (`state_id`),
  CONSTRAINT `user_id_add_prod` FOREIGN KEY (`user_id_add`) REFERENCES `users` (`user_id`),
  CONSTRAINT `user_id_mod_prod` FOREIGN KEY (`user_id_mod`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'Todo Riesgo','Proteje tu vehículo con este seguro. Te cubre TODO',2000000.00,1,1,'2024-11-16 00:00:00',NULL,NULL),(2,2,'Desvare','Desvaramos tu moto. Te ofrecemos taller móvil 24/7',1750000.00,1,1,'2024-11-16 00:00:00',NULL,NULL),(3,3,'Cubre tu vida','Cubre tu vida y dale tranquilidad a los que amas',20000000.00,1,1,'2024-11-16 00:00:00',NULL,NULL),(4,4,'Seguro de cerrajería','¿Se dañó la chapa? ¡Nosotros te ayudamos!',500000.00,1,1,'2024-11-16 00:00:00',NULL,NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-18 10:47:50
